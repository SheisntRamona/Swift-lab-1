let x = 5 /* assigning constant variable (immutable) */

var y = 7 /* mutable variable, cannot ever change variable type */

y = 6 /* updates y value, only when given value of samne type as original value */

var z: Double = 8 /* declaration of specific type */

z = 2.5 /* works because z holds a double as noted in original declaration */

/* structure allows for block variables, keeping related variables togther */

struct Person {
    var firstName: String
    var lastName: String
}

var me = Person(firstName: "Charlie", lastName: "May")

/* printing structure variables */
print(me.firstName)
print(me.lastName)

/* arrays */
let numbers = [1, 2, 3, 4, 5]
/* counting array items */
let n = numbers.count
/* getting array items by index */
print(numbers[2])
/* getting last element using count */
print(numbers[n-1])

/* dictionaries */
let dictionary = ["one" : 1, "two" : 2, "three" : 3 ]
/* get value from dictionary key */
var a = dictionary["one"]
