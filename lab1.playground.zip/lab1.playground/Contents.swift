import Foundation

print("Enter your name: ")
let name = readLine()
print("Hello, \(name!).")
